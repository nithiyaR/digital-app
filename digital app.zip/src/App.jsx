
    import React from 'react';
    import { Toaster } from '@/components/ui/toaster';
    import HeroSection from '@/components/HeroSection';
    import WhatYoullLearnSection from '@/components/WhatYoullLearnSection';
    import WhoCanJoinSection from '@/components/WhoCanJoinSection';
    import CourseFeaturesSection from '@/components/CourseFeaturesSection';
    import Footer from '@/components/Footer';

    function App() {
      return (
        <div className="min-h-screen bg-brand-white text-brand-black flex flex-col">
          <header className="p-4 shadow-md bg-brand-white sticky top-0 z-50 border-b border-gray-200">
            <div className="container mx-auto flex justify-between items-center">
              <img 
                src="https://storage.googleapis.com/hostinger-horizons-assets-prod/707d4896-ece9-4ef1-bb1b-9c6f857749b8/2680447032df5fb3a60c7d8e262d2a0c.jpg" 
                alt="Digital Digitizers Logo" 
                className="h-16 md:h-20" 
              />
            </div>
          </header>
          <main className="flex-grow">
            <HeroSection />
            <WhatYoullLearnSection />
            <WhoCanJoinSection />
            <CourseFeaturesSection />
          </main>
          <Footer />
          <Toaster />
        </div>
      );
    }

    export default App;
  