
    import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
    import { CheckCircle, Target, Rocket, MessageCircle, Briefcase, Gift, Award, Presentation } from 'lucide-react';

    const learningPoints = [
      { icon: <Target size={36} className="text-pink-500" />, title: "SEO Basics", description: "Rank Websites with On-Page & Off-Page Techniques" },
      { icon: <Rocket size={36} className="text-red-500" />, title: "Google Ads & Meta Ads", description: "Live Ad Campaign Setup & Optimization" },
      { icon: <Presentation size={36} className="text-purple-500" />, title: "Landing Page Creation", description: "Design High-Conversion Ready Pages" },
      { icon: <MessageCircle size={36} className="text-yellow-500" />, title: "WhatsApp Automation", description: "Smart Lead Follow-up System Implementation" },
      { icon: <Briefcase size={36} className="text-green-500" />, title: "Freelancing Platforms", description: "Start Earning from Day 1 on Popular Platforms" },
    ];

    const bonusPoints = [
      { icon: <Gift size={28} className="text-indigo-400" />, title: "Interview Tips & Tricks" },
      { icon: <Award size={28} className="text-indigo-400" />, title: "Professional Resume Building" },
      { icon: <CheckCircle size={28} className="text-indigo-400" />, title: "Proven Earning Strategies" },
    ];

    const WhatYoullLearnSection = () => {
      const cardVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: (i) => ({
          opacity: 1,
          y: 0,
          transition: {
            delay: i * 0.1,
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };

      return (
        <section className="py-16 md:py-24 bg-slate-800">
          <div className="container mx-auto px-4">
            <motion.h2 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl font-bold text-center mb-6 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-red-400 to-yellow-400"
            >
              What You’ll Learn
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg text-center text-slate-300 mb-12 max-w-2xl mx-auto"
            >
              Master essential digital marketing skills with our intensive, hands-on curriculum designed for rapid learning and immediate application.
            </motion.p>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
              {learningPoints.map((point, index) => (
                <motion.custom
                  key={index}
                  variants={cardVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.3 }}
                  custom={index}
                  className="h-full"
                >
                  <Card className="glassmorphism-card h-full transform hover:scale-105 transition-transform duration-300 hover:shadow-2xl hover:shadow-primary/30">
                    <CardHeader className="flex flex-row items-center gap-4 pb-2">
                      {point.icon}
                      <CardTitle className="text-2xl font-semibold text-slate-100">{point.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-slate-300">{point.description}</p>
                    </CardContent>
                  </Card>
                </motion.custom>
              ))}
            </div>
            
            <motion.div 
              className="mt-16 text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.6, delay: 0.5 }}
            >
              <h3 className="text-3xl font-bold mb-8 text-slate-100">
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-cyan-400">
                  Exclusive Bonuses
                </span>
              </h3>
              <div className="flex flex-wrap justify-center gap-6 md:gap-10">
                {bonusPoints.map((bonus, index) => (
                  <motion.div 
                    key={index} 
                    className="glassmorphism-card p-6 flex flex-col items-center text-center w-full sm:w-auto sm:min-w-[200px] transform hover:scale-105 transition-transform duration-300"
                    variants={cardVariants}
                    custom={learningPoints.length + index}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, amount: 0.3 }}
                  >
                    {bonus.icon}
                    <p className="mt-3 text-lg font-medium text-slate-200">{bonus.title}</p>
                  </motion.div>
                ))}
              </div>
            </motion.div>

          </div>
        </section>
      );
    };

    export default WhatYoullLearnSection;
  