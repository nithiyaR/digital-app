
    import React from 'react';
    import { Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

    const Footer = () => {
      const currentYear = new Date().getFullYear();
      return (
        <footer className="bg-brand-black text-brand-white py-12">
          <div className="container mx-auto px-4 text-center">
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-brand-white mb-2">Digital Digitizers</h3>
              <p className="text-sm text-gray-400">India's No.1 Digital Marketing Company</p>
            </div>
            <div className="flex justify-center space-x-6 mb-8">
              <a href="#" className="text-gray-400 hover:text-brand-skyBlue transition-colors duration-300"><Facebook size={24} /></a>
              <a href="#" className="text-gray-400 hover:text-brand-skyBlue transition-colors duration-300"><Twitter size={24} /></a>
              <a href="#" className="text-gray-400 hover:text-brand-skyBlue transition-colors duration-300"><Instagram size={24} /></a>
              <a href="#" className="text-gray-400 hover:text-brand-skyBlue transition-colors duration-300"><Linkedin size={24} /></a>
            </div>
            <p className="text-sm text-gray-400">
              &copy; {currentYear} Digital Digitizers. All rights reserved.
            </p>
            <p className="text-xs mt-2 text-gray-500">
              Empowering careers through cutting-edge digital marketing education.
            </p>
          </div>
        </footer>
      );
    };

    export default Footer;
  