
    import React from 'react';
    import { motion } from 'framer-motion';
    import { Card, CardContent } from '@/components/ui/card';
    import { User, Briefcase, GraduationCap, Users } from 'lucide-react';

    const targetAudience = [
      { icon: <GraduationCap size={40} className="text-green-400" />, title: "Freshers", description: "Kickstart your career in the booming digital marketing industry." },
      { icon: <Briefcase size={40} className="text-blue-400" />, title: "Working Professionals", description: "Upskill or switch careers to a high-demand field." },
      { icon: <User size={40} className="text-yellow-400" />, title: "Students", description: "Gain practical skills and a competitive edge before graduating." },
      { icon: <Users size={40} className="text-purple-400" />, title: "Business Owners & Freelancers", description: "Grow your business or services with effective digital strategies." },
    ];

    const WhoCanJoinSection = () => {
      const cardVariants = {
        hidden: { opacity: 0, scale: 0.9 },
        visible: (i) => ({
          opacity: 1,
          scale: 1,
          transition: {
            delay: i * 0.15,
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };

      return (
        <section className="py-16 md:py-24 bg-gradient-to-br from-slate-800 to-slate-900">
          <div className="container mx-auto px-4">
            <motion.h2 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl md:text-5xl font-bold text-center mb-12 bg-clip-text text-transparent bg-gradient-to-r from-green-400 via-blue-400 to-purple-400"
            >
              Who Can Join This Course?
            </motion.h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {targetAudience.map((audience, index) => (
                <motion.custom
                  key={index}
                  variants={cardVariants}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, amount: 0.3 }}
                  custom={index}
                  className="h-full"
                >
                  <Card className="glassmorphism-card text-center p-6 h-full flex flex-col items-center justify-start transform hover:shadow-2xl hover:shadow-accent/30 transition-shadow duration-300">
                    <div className="mb-4 p-3 bg-slate-700/50 rounded-full">
                      {audience.icon}
                    </div>
                    <h3 className="text-2xl font-semibold text-slate-100 mb-2">{audience.title}</h3>
                    <CardContent className="p-0">
                      <p className="text-slate-300 text-sm">{audience.description}</p>
                    </CardContent>
                  </Card>
                </motion.custom>
              ))}
            </div>
          </div>
        </section>
      );
    };

    export default WhoCanJoinSection;
  