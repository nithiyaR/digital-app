
    import React from 'react';
    import { Button } from '@/components/ui/button';
    import { motion } from 'framer-motion';
    import { Zap, Users, Award } from 'lucide-react';

    const HeroSection = () => {
      return (
        <section className="relative py-20 md:py-32 bg-brand-skyBlue text-brand-white overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <img  class="w-full h-full object-cover" alt="Abstract blue digital pattern" src="https://images.unsplash.com/photo-1567799316643-6becf0aba711" />
          </div>
          <div className="container mx-auto px-4 relative z-10 text-center">
            <motion.h1
              initial={{ opacity: 0, y: -50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, ease: "easeOut" }}
              className="text-4xl md:text-6xl font-extrabold mb-6 leading-tight text-brand-white"
            >
              Become a Digital Marketer in Just 7 Days
              <br className="hidden md:block" />
              <span className="text-brand-black">
                Guaranteed Job or Freelance Earning!
              </span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
              className="text-lg md:text-2xl mb-10 font-light text-brand-white"
            >
              Powered by <span className="font-semibold">Digital Digitizers</span> – India's No.1 Digital Marketing Company
            </motion.p>
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.7, delay: 0.6, type: "spring", stiffness: 120 }}
            >
              <Button size="lg" className="bg-brand-black hover:bg-gray-800 text-brand-white font-bold text-lg px-10 py-6 rounded-full shadow-xl transform hover:scale-105 transition-transform duration-300 group">
                JOIN NOW
                <span className="ml-2 text-sm opacity-80 group-hover:opacity-100 transition-opacity duration-300">
                  Limited Seats! Live Training & Certification
                </span>
              </Button>
            </motion.div>
            <motion.div 
              className="mt-16 flex flex-wrap justify-center gap-8 md:gap-12"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.9, ease: "easeOut" }}
            >
              <div className="flex items-center space-x-2 text-brand-white">
                <Zap size={24} />
                <span className="font-medium">Fast-Track Learning</span>
              </div>
              <div className="flex items-center space-x-2 text-brand-white">
                <Users size={24} />
                <span className="font-medium">Expert Instructors</span>
              </div>
              <div className="flex items-center space-x-2 text-brand-white">
                <Award size={24} />
                <span className="font-medium">Valuable Certification</span>
              </div>
            </motion.div>
          </div>
        </section>
      );
    };

    export default HeroSection;
  