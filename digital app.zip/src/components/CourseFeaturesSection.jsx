
    import React from 'react';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { PlaySquare, Edit3, CalendarCheck, Sparkles } from 'lucide-react';

    const features = [
      { icon: <PlaySquare size={32} className="text-pink-400" />, text: "Live + Recorded Lessons for Flexible Learning" },
      { icon: <Edit3 size={32} className="text-red-400" />, text: "100% Practical Assignments Daily to Solidify Skills" },
      { icon: <CalendarCheck size={32} className="text-yellow-400" />, text: "Intensive 7-Day Fast-Track Program" },
      { icon: <Sparkles size={32} className="text-purple-400" />, text: "Job & Freelance Earning Guarantee*" },
    ];

    const CourseFeaturesSection = () => {
      const listItemVariants = {
        hidden: { opacity: 0, x: -20 },
        visible: (i) => ({
          opacity: 1,
          x: 0,
          transition: {
            delay: i * 0.15,
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };

      return (
        <section className="py-16 md:py-24 bg-slate-800">
          <div className="container mx-auto px-4">
            <div className="flex flex-col lg:flex-row items-center gap-12">
              <motion.div 
                className="lg:w-1/2"
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.7, ease: "easeOut" }}
              >
                <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-pink-400 via-red-400 to-yellow-400">
                  Course Features
                </h2>
                <p className="text-lg text-slate-300 mb-8">
                  Our 7-Day Digital Marketing Crash Course is packed with features designed for your success. Experience interactive learning, practical application, and dedicated support.
                </p>
                <ul className="space-y-5 mb-10">
                  {features.map((feature, index) => (
                    <motion.li 
                      key={index} 
                      className="flex items-start gap-4"
                      custom={index}
                      variants={listItemVariants}
                      initial="hidden"
                      whileInView="visible"
                      viewport={{ once: true, amount: 0.2 }}
                    >
                      <div className="flex-shrink-0 mt-1">{feature.icon}</div>
                      <span className="text-slate-200 text-lg">{feature.text}</span>
                    </motion.li>
                  ))}
                </ul>
                <Button size="lg" className="bg-gradient-to-r from-pink-500 to-red-500 hover:from-pink-600 hover:to-red-600 text-white font-bold text-lg px-10 py-6 rounded-full shadow-xl transform hover:scale-105 transition-transform duration-300">
                  Enroll Now & Transform Your Career!
                </Button>
                 <p className="text-xs text-slate-400 mt-2">*Terms and conditions apply for guarantee.</p>
              </motion.div>
              <motion.div 
                className="lg:w-1/2 relative"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.7, ease: "easeOut", delay:0.2 }}
              >
                <div className="aspect-video rounded-xl overflow-hidden shadow-2xl border-4 border-primary/30">
                   <img  class="w-full h-full object-cover" alt="Team collaborating on digital marketing strategy" src="https://images.unsplash.com/photo-1567080185975-88eedc2b273a" />
                </div>
                <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-yellow-400 rounded-full opacity-30 blur-2xl -z-10"></div>
                <div className="absolute -top-8 -left-8 w-40 h-40 bg-pink-500 rounded-full opacity-20 blur-2xl -z-10"></div>
              </motion.div>
            </div>
          </div>
        </section>
      );
    };

    export default CourseFeaturesSection;
  